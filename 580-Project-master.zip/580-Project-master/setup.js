export var soundOn = false;
export var midiOn = true;
export var transpose = 0;

export function toggleSound() {
    soundOn = !soundOn;
}

export function setup() {
    //midi setup
    if (navigator.requestMIDIAccess) {
        // console.log('This browser supports WebMIDI!');
        navigator.requestMIDIAccess().then(onMIDISuccess, onMIDIFailure);
    } else {
        // console.log('WebMIDI is not supported in this browser.');
    }
}

function onMIDISuccess(midiAccess) {
    MIDI.loadPlugin({
        soundfontUrl: "./soundfont/",
        instrument: "acoustic_grand_piano",
        onprogress: function(state, progress) {
            // console.log(state, progress);
        },
        onsuccess: function() {
            // console.log("Output is setup");
        }
    });
	var inputs = midiAccess.inputs;
	var outputs = midiAccess.outputs;

	for (var input of midiAccess.inputs.values()) {
		input.onmidimessage = getMIDIMessage;
	}
}

function onMIDIFailure() {
	document.querySelector('.step0').innerHTML = 'Error: Could not access MIDI devices. Connect a device and refresh to try again.';
}

function getMIDIMessage(message) {
	var command = message.data[0];
	var note = message.data[1];
	var velocity = (message.data.length > 2) ? message.data[2] : 0;
    var delay = 0;

	switch (command) {
		case 144: // noteOn
			if (velocity > 0) {
                console.log("midi: " + note);
                if (midiOn) { MIDI.noteOn(0, note, velocity, delay); }
                this.noteOnListener(note, velocity);
			} else {
                MIDI.noteOff(0, note, delay);
				if (midiOn) { this.noteOffListener(note); }
			}
			break;
        case 128: // noteOff
            if (midiOn) { MIDI.noteOff(0, note, delay); }
			noteOffCallback(note);
			break;
	}
}

export function toggleMIDI() {
    midiOn = !midiOn;
}

//text to speech helpers
export function say(text) {
    var msg = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(msg);
}

//midi setup and helpers
export function playNote(note) {
    var delay = 0;
    var velocity = 127;
    MIDI.noteOn(0, note, velocity, delay);
    MIDI.noteOff(0, note, delay + 0.75);
    console.log("Keyboard: " + note);
    notePressed(note);
}

export function playNoteString(letter, octave) {
    octave = (octave * 12) + 12;
    switch(letter) {
        case "A":
            playNote(-3+octave);
            break;
        case "A#":
            playNote(-2+octave);
            break;
        case "B":
            playNote(-1+octave);
            break;
        case "C":
            playNote(0+octave);
            break;
        case "C#":
            playNote(1+octave);
            break;
        case "D": 
            playNote(2+octave);
            break;
        case "D#": 
            playNote(3+octave);
            break;
        case "E":
            playNote(4+octave);
            break;
        case "F":
            playNote(5+octave);
            break;
        case "F#":
            playNote(6+octave);
            break;
        case "G":
            playNote(7+octave);
            break;
        case "G#":
            playNote(8+octave);
            break;
    }
}

export function listenKeyNote(info) {
    $(document).keydown(function(e){
        //transposes up or down an octave
        if(e.keyCode == 72) {transpose+=12; console.log("T: " + transpose);}
        if(e.keyCode == 71) {transpose-=12;}
        //using the keyboard as a piano
        if(e.keyCode == 65) {playNote(60+transpose);} //C4
        if(e.keyCode == 87) {playNote(61+transpose);} //C#4
        if(e.keyCode == 83) {playNote(62+transpose);} //D4
        if(e.keyCode == 69) {playNote(63+transpose);} //D#4
        if(e.keyCode == 68) {playNote(64+transpose);} //E4
        if(e.keyCode == 70) {playNote(65+transpose);} //F4
        if(e.keyCode == 84) {playNote(66+transpose);} //F#4
        if(e.keyCode == 74) {playNote(67+transpose);} //G4
        if(e.keyCode == 73) {playNote(68+transpose);} //G#4
        if(e.keyCode == 75) {playNote(69+transpose);} //A5
        if(e.keyCode == 79) {playNote(70+transpose);} //A#5
        if(e.keyCode == 76) {playNote(71+transpose);} //B5
        if(e.keyCode == 186) {playNote(72+transpose);} //C5
    }); 
}

export function stopListen(info) {
    $(document).off();
}